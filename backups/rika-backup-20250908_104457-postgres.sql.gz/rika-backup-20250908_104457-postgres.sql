--
-- PostgreSQL database cluster dump
--

\restrict Cxv7pH37PUem5RYx4iw6TCGdctyfO9jC6HjTdZjP8O4N0rqnNNoVCrWdUT7QdJ2

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE rika_admin;
ALTER ROLE rika_admin WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:yXaqxfHishqBmj/dcJKtBg==$UkSiHATa1nIhlcoF3F6s5Sc4ZVMUF9p0vplZAx0/8uQ=:2U0XUBbm8qhvz+wnIRwdnKT99pPYdc2cvXNWKHF/GVc=';

--
-- User Configurations
--








\unrestrict Cxv7pH37PUem5RYx4iw6TCGdctyfO9jC6HjTdZjP8O4N0rqnNNoVCrWdUT7QdJ2

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict I8a1OTf2cLAGMEXDSNGmiiyL84RStoLsGve7hmkGOpCP4hETlMdui5MDSZkJ6fx

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict I8a1OTf2cLAGMEXDSNGmiiyL84RStoLsGve7hmkGOpCP4hETlMdui5MDSZkJ6fx

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict KSSiWVJzPwTtKaifQOCpEX3hE6cIAU4uJjicPRe6v8GXZh26qboDKWTPbL9HBgH

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict KSSiWVJzPwTtKaifQOCpEX3hE6cIAU4uJjicPRe6v8GXZh26qboDKWTPbL9HBgH

--
-- Database "rika_core" dump
--

--
-- PostgreSQL database dump
--

\restrict fDT2PytnUTcxZKxaCPYoLfpLBVhgtbgsRiThPNIzGmLqQyhHQpPvnWdTTOF7vmg

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: rika_core; Type: DATABASE; Schema: -; Owner: rika_admin
--

CREATE DATABASE rika_core WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE rika_core OWNER TO rika_admin;

\unrestrict fDT2PytnUTcxZKxaCPYoLfpLBVhgtbgsRiThPNIzGmLqQyhHQpPvnWdTTOF7vmg
\connect rika_core
\restrict fDT2PytnUTcxZKxaCPYoLfpLBVhgtbgsRiThPNIzGmLqQyhHQpPvnWdTTOF7vmg

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict fDT2PytnUTcxZKxaCPYoLfpLBVhgtbgsRiThPNIzGmLqQyhHQpPvnWdTTOF7vmg

--
-- PostgreSQL database cluster dump complete
--

