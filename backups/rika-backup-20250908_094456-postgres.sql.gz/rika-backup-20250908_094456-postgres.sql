--
-- PostgreSQL database cluster dump
--

\restrict E3G2k8nQ2yp80RtmSCNhrQLe7LhEMEKmQZS7qOy1eemePkERZtsEP49MdVXEjnj

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE rika_admin;
ALTER ROLE rika_admin WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:yXaqxfHishqBmj/dcJKtBg==$UkSiHATa1nIhlcoF3F6s5Sc4ZVMUF9p0vplZAx0/8uQ=:2U0XUBbm8qhvz+wnIRwdnKT99pPYdc2cvXNWKHF/GVc=';

--
-- User Configurations
--








\unrestrict E3G2k8nQ2yp80RtmSCNhrQLe7LhEMEKmQZS7qOy1eemePkERZtsEP49MdVXEjnj

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict 189HSdnTmVddy8axDAdO5iyQ3DiJUCFgJxdvq4g06j7tWsGfP79kLanrA5mB9nH

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict 189HSdnTmVddy8axDAdO5iyQ3DiJUCFgJxdvq4g06j7tWsGfP79kLanrA5mB9nH

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict nTgN6GFOnY9hhnoEFGev0rtcrtsyl2BbLfRs8bDwYEvxOa2C3VAGUdalAgxQlP4

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict nTgN6GFOnY9hhnoEFGev0rtcrtsyl2BbLfRs8bDwYEvxOa2C3VAGUdalAgxQlP4

--
-- Database "rika_core" dump
--

--
-- PostgreSQL database dump
--

\restrict Pe3iSZ3KXtFY3wKcuUcS8vOqOQogMaTvVt4h96gHYqFr8vD30oIo90qufmaaSt8

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: rika_core; Type: DATABASE; Schema: -; Owner: rika_admin
--

CREATE DATABASE rika_core WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE rika_core OWNER TO rika_admin;

\unrestrict Pe3iSZ3KXtFY3wKcuUcS8vOqOQogMaTvVt4h96gHYqFr8vD30oIo90qufmaaSt8
\connect rika_core
\restrict Pe3iSZ3KXtFY3wKcuUcS8vOqOQogMaTvVt4h96gHYqFr8vD30oIo90qufmaaSt8

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict Pe3iSZ3KXtFY3wKcuUcS8vOqOQogMaTvVt4h96gHYqFr8vD30oIo90qufmaaSt8

--
-- PostgreSQL database cluster dump complete
--

